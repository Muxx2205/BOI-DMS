<%@page import="com.liferay.portal.kernel.util.Validator"%>
<%@page import="com.liferay.portal.kernel.util.ParamUtil"%>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ include file="/init.jsp" %>

<%
String success = ParamUtil.getString(request, "success");
String error = ParamUtil.getString(request, "error");
%>

<portlet:actionURL name="startBulkDelete" var="startBulkDeleteURL" />
<portlet:actionURL name="startURNBulkDelete" var="startURNBulkDelete" />
<portlet:actionURL name="startBulkWorkflowDelete" var="startBulkWorkflowDeleteURL" />
<portlet:actionURL name="startBulkUpdateAccountNo" var="startBulkUpdateAccountNoURL" />
<portlet:actionURL name="exportObjectDataByURNs" var="exportObjectDataByURNsURL" />
<portlet:actionURL name="startFinacleConsentSync" var="startFinacleConsentSyncURL" />
<style>
    /* Bootstrap 5 Custom Styles */
    :root {
        --bs-primary: #4361ee;
        --bs-success: #06ffa5;
        --bs-danger: #ef233c;
        --bs-warning: #ff9f1c;
        --bs-dark: #2b2d42;
        --bs-gray: #8d99ae;
        --bs-light: #edf2f4;
        --bs-info: #0ea5e9;
        --bs-purple: #8b5cf6;
    }
    
    .delete-container {
        padding: 2rem;
        background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        min-height: 100vh;
    }
    
    /* Header Section */
    .header-section {
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .header-section h1 {
        font-size: 2.5rem;
        font-weight: 700;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: 0.5rem;
    }
    
    .header-section p {
        color: #6c757d;
        font-size: 1rem;
    }
    
    /* Stats Cards */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin-bottom: 2rem;
    }
    
    .stat-card {
        background: white;
        border-radius: 1rem;
        padding: 1.25rem;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.07);
        transition: transform 0.2s;
        border: 1px solid rgba(0,0,0,0.05);
    }
    
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 15px rgba(0,0,0,0.1);
    }
    
    .stat-icon {
        font-size: 2rem;
        margin-bottom: 0.5rem;
    }
    
    .stat-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #4361ee;
        margin-bottom: 0.25rem;
    }
    
    .stat-label {
        font-size: 0.875rem;
        color: #6c757d;
        font-weight: 500;
    }
    
    /* Tab Navigation */
    .nav-tabs-custom {
        border-bottom: 2px solid #e9ecef;
        margin-bottom: 1.5rem;
        display: flex;
        gap: 0.5rem;
        flex-wrap: wrap;
    }
    
    .nav-tab {
        padding: 0.75rem 1.5rem;
        background: transparent;
        border: none;
        font-weight: 600;
        color: #6c757d;
        cursor: pointer;
        transition: all 0.3s;
        border-radius: 0.5rem 0.5rem 0 0;
        position: relative;
    }
    
    .nav-tab.active {
        color: #4361ee;
        background: white;
    }
    
    .nav-tab.active::after {
        content: '';
        position: absolute;
        bottom: -2px;
        left: 0;
        right: 0;
        height: 2px;
        background: #4361ee;
    }
    
    .nav-tab:hover:not(.active) {
        color: #4361ee;
        background: rgba(67, 97, 238, 0.05);
    }
    
    /* Tab Content */
    .tab-content {
        display: none;
        animation: fadeIn 0.3s ease;
    }
    
    .tab-content.active {
        display: block;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Cards */
    .card-custom {
        background: white;
        border-radius: 1rem;
        box-shadow: 0 10px 40px rgba(0,0,0,0.08);
        overflow: hidden;
        margin-bottom: 1.5rem;
        border: 1px solid rgba(0,0,0,0.05);
    }
    
    .card-header-custom {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.25rem 1.5rem;
        font-weight: 600;
        font-size: 1.1rem;
    }
    
    .card-header-custom.export-header {
        background: linear-gradient(135deg, #0ea5e9 0%, #8b5cf6 100%);
    }
    
    .card-header-custom i {
        margin-right: 0.5rem;
    }
    
    .card-body-custom {
        padding: 1.5rem;
    }
    
    /* Form Groups */
    .form-group-custom {
        margin-bottom: 1.5rem;
    }
    
    .form-label-custom {
        display: block;
        font-weight: 600;
        margin-bottom: 0.5rem;
        color: #2b2d42;
        font-size: 0.9rem;
    }
    
    .form-label-custom .required {
        color: #ef233c;
        margin-left: 0.25rem;
    }
    
    .form-control-custom {
        width: 100%;
        padding: 0.625rem 0.875rem;
        border: 1px solid #dee2e6;
        border-radius: 0.5rem;
        font-size: 0.9rem;
        transition: all 0.2s;
    }
    
    .form-control-custom:focus {
        outline: none;
        border-color: #4361ee;
        box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
    }
    
    select.form-control-custom {
        cursor: pointer;
    }
    
    /* Checkbox Group */
    .checkbox-group-custom {
        display: flex;
        flex-wrap: wrap;
        gap: 1rem;
        margin-top: 0.5rem;
    }
    
    .checkbox-custom {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        cursor: pointer;
    }
    
    .checkbox-custom input[type="checkbox"] {
        width: 1rem;
        height: 1rem;
        cursor: pointer;
    }
    
    .checkbox-custom label {
        cursor: pointer;
        font-size: 0.9rem;
        color: #2b2d42;
    }
    
    /* Upload Area */
    .upload-area-custom {
        border: 2px dashed #dee2e6;
        border-radius: 0.75rem;
        padding: 2rem;
        text-align: center;
        background: #f8f9fa;
        transition: all 0.2s;
        cursor: pointer;
    }
    
    .upload-area-custom:hover {
        border-color: #4361ee;
        background: #f1f3f5;
    }
    
    .upload-icon {
        font-size: 2.5rem;
        margin-bottom: 0.5rem;
    }
    
    .upload-text {
        color: #6c757d;
        font-size: 0.9rem;
    }
    
    .upload-text strong {
        color: #4361ee;
    }
    
    .file-info-custom {
        font-size: 0.8rem;
        color: #6c757d;
        margin-top: 0.5rem;
    }
    
    /* Buttons */
    .btn-custom {
        width: 100%;
        padding: 0.875rem;
        border: none;
        border-radius: 0.5rem;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        transition: all 0.2s;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
    }
    
    .btn-custom:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }
    
    .btn-danger-custom {
        background: linear-gradient(135deg, #ef233c 0%, #d90429 100%);
    }
    
    .btn-danger-custom:hover {
        box-shadow: 0 4px 12px rgba(239, 35, 60, 0.4);
    }
    
    .btn-export-custom {
        background: linear-gradient(135deg, #0ea5e9 0%, #8b5cf6 100%);
    }
    
    .btn-export-custom:hover {
        box-shadow: 0 4px 12px rgba(14, 165, 233, 0.4);
    }
    
    /* Alert Boxes */
    .alert-custom {
        padding: 1rem;
        border-radius: 0.5rem;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        animation: slideDown 0.3s ease;
    }
    
    @keyframes slideDown {
        from { transform: translateY(-20px); opacity: 0; }
        to { transform: translateY(0); opacity: 1; }
    }
    
    .alert-success-custom {
        background: #d1fae5;
        border-left: 4px solid #10b981;
        color: #065f46;
    }
    
    .alert-danger-custom {
        background: #fee2e2;
        border-left: 4px solid #ef233c;
        color: #991b1b;
    }
    
    .alert-icon {
        font-size: 1.25rem;
    }
    
    /* Info Boxes */
    .info-box-custom {
        background: #e0f2fe;
        border-left: 4px solid #0ea5e9;
        padding: 1rem;
        border-radius: 0.5rem;
        margin-top: 1rem;
    }
    
    .warning-box-custom {
        background: #fed7aa;
        border-left: 4px solid #f97316;
        padding: 1rem;
        border-radius: 0.5rem;
        margin-top: 1rem;
    }
    
    .sample-csv-custom {
        background: #f1f5f9;
        padding: 0.75rem;
        border-radius: 0.5rem;
        font-family: 'Courier New', monospace;
        font-size: 0.8rem;
        margin: 0.75rem 0;
        border: 1px solid #e2e8f0;
    }
    
    /* Lists */
    .list-custom {
        margin: 0.75rem 0 0 1.25rem;
        padding: 0;
    }
    
    .list-custom li {
        margin-bottom: 0.5rem;
        line-height: 1.4;
    }
    
    /* Grid System */
    .row-custom {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
        margin-bottom: 1.5rem;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
        .delete-container {
            padding: 1rem;
        }
        
        .stats-grid {
            grid-template-columns: repeat(2, 1fr);
        }
        
        .row-custom {
            grid-template-columns: 1fr;
        }
        
        .nav-tabs-custom {
            flex-direction: column;
        }
        
        .nav-tab {
            text-align: center;
        }
    }
    
    /* Hide file input */
    input[type="file"] {
        display: none;
    }
    
    /* Loading Spinner */
    .loading-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
    }
    
    .spinner-custom {
        width: 50px;
        height: 50px;
        border: 4px solid #f3f3f3;
        border-top: 4px solid #4361ee;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>

<div class="delete-container">
    <!-- Header Section -->
    <div class="header-section">
        <h1>Bulk Operations Manager</h1>
        <p>Efficiently manage bulk delete operations for PMS BY records</p>
        <hr style="width: 100px; margin: 1rem auto; border: 2px solid #4361ee;">
    </div>
    
    <!-- Alerts -->
    <c:if test="<%= Validator.isNotNull(success) %>">
        <div class="alert-custom alert-success-custom">
            <div class="alert-icon"></div>
            <div><%= success %></div>
        </div>
    </c:if>
    
    <c:if test="<%= Validator.isNotNull(error) %>">
        <div class="alert-custom alert-danger-custom">
            <div class="alert-icon"></div>
            <div><%= error %></div>
        </div>
    </c:if>
    
    <!-- Loading Overlay (hidden by default) -->
    <div id="loadingOverlay" style="display: none;">
        <div class="loading-overlay">
            <div class="spinner-custom"></div>
        </div>
    </div>
    
    <!-- Tab Navigation -->
    <div class="nav-tabs-custom">
        <button class="nav-tab active" onclick="showTab('by-id')"> Delete by IDs</button>
        <button class="nav-tab" onclick="showTab('by-urn')"> Delete by URNs</button>
        <button class="nav-tab" onclick="showTab('workflow')"> Workflow Cleanup</button>
        <button class="nav-tab" onclick="showTab('update-account')"> Update Account No</button>
        <button class="nav-tab" onclick="showTab('export-data')"> Export by URNs</button>
        <button class="nav-tab" onclick="showTab('finacle-consent')"> Finacle Consent</button>
    </div>
    
    <!-- Tab 1: Delete by Object Entry IDs -->
    <div id="by-id" class="tab-content active">
        <div class="card-custom">
            <div class="card-header-custom">
                <i></i> Bulk Delete by Object Entry IDs
            </div>
            <div class="card-body-custom">
                <aui:form action="<%= startBulkDeleteURL %>" method="post" enctype="multipart/form-data" name="deleteForm">
                    <div class="form-group-custom">
                        <label class="form-label-custom">
                            CSV File with Object Entry IDs
                            <span class="required">*</span>
                        </label>
                        <div class="upload-area-custom" onclick="document.getElementById('<portlet:namespace />csvFile').click();">
                            <div class="upload-icon"></div>
                            <div class="upload-text">
                                <strong>Click to select</strong> or drag & drop CSV file
                            </div>
                        </div>
                        <aui:input 
                            name="csvFile" 
                            type="file" 
                            id="csvFile"
                            accept=".csv"
                            required="true"
                            label=""
                            style="display: none;"
                        />
                        <div class="file-info-custom" id="fileInfo">
                            Supported formats: .csv (Max 250K records)
                        </div>
                    </div>
                    
                    <div class="row-custom">
                        <div class="form-group-custom">
                            <label class="form-label-custom">ID Column Name</label>
                            <aui:input 
                                name="idColumnName" 
                                type="text" 
                                id="idColumnName"
                                value="objectEntryId"
                                placeholder="e.g., objectEntryId, id, entryId"
                                label=""
                            >
                                <aui:validator name="required" />
                            </aui:input>
                            <div class="file-info-custom">Column header containing Object Entry IDs</div>
                        </div>
                        
                        <div class="form-group-custom">
                            <label class="form-label-custom">CSV Delimiter</label>
                            <select name="<portlet:namespace />delimiter" id="delimiter" class="form-control-custom">
                                <option value=",">Comma (,)</option>
                                <option value=";">Semicolon (;)</option>
                                <option value="\t">Tab</option>
                                <option value="|">Pipe (|)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group-custom">
                        <label class="form-label-custom">Description (Optional)</label>
                        <aui:input 
                            name="description" 
                            type="text" 
                            id="description"
                            placeholder="e.g., Jan 2024 cleanup, Zone DHANBAD records"
                            label=""
                        />
                    </div>
                    
                    <button type="submit" class="btn-custom">
                         Upload and Delete Records
                    </button>
                </aui:form>
                
                <div class="warning-box-custom">
                    <strong> Important Notes:</strong>
                    <ul class="list-custom">
                        <li>CSV file must have a header row with ID column</li>
                        <li>Each ID will be permanently deleted from the database</li>
                        <li>Operation runs in background - you can close this window</li>
                        <li>Track progress in <strong>Control Panel  System  Background Tasks</strong></li>
                    </ul>
                    <div class="sample-csv-custom">
                        <strong>Sample CSV format:</strong><br>
                        objectEntryId,otherData<br>
                        390811,optional data<br>
                        390812,optional data<br>
                        390813,optional data
                    </div>
                </div>
                
                <div class="info-box-custom">
                    <strong> Tips for large files (250K records):</strong>
                    <ul class="list-custom">
                        <li>Ensure CSV has only numeric IDs in the ID column</li>
                        <li>Remove any duplicate IDs to save processing time</li>
                        <li>The system will process 5,000 records per batch with 5 parallel threads</li>
                        <li>Progress is logged every 10,000 records</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tab 2: Delete by URNs -->
    <div id="by-urn" class="tab-content">
        <div class="card-custom">
            <div class="card-header-custom">
                <i></i> Bulk Delete by URNs (Duplicate Cleanup)
            </div>
            <div class="card-body-custom">
                <div class="info-box-custom" style="background: #dbeafe; border-left-color: #3b82f6;">
                    <strong> Duplicate Cleanup Strategy:</strong>
                    <ul class="list-custom">
                        <li>Keeps record with lowest stage value (0 < 1 < 2 < 3)</li>
                        <li>If stages are equal, keeps the oldest record</li>
                        <li>Deletes all other duplicate records</li>
                    </ul>
                </div>
                
                <aui:form action="<%= startURNBulkDelete %>" method="post" enctype="multipart/form-data" name="deleteURNForm">
                    <div class="form-group-custom">
                        <label class="form-label-custom">
                            CSV File with URNs
                            <span class="required">*</span>
                        </label>
                        <div class="upload-area-custom" onclick="document.getElementById('<portlet:namespace />csvURNFile').click();">
                            <div class="upload-icon"></div>
                            <div class="upload-text">
                                <strong>Click to select</strong> CSV file with URNs
                            </div>
                        </div>
                        <aui:input 
                            name="csvURNFile" 
                            type="file" 
                            id="csvURNFile"
                            accept=".csv"
                            required="true"
                            label=""
                            style="display: none;"
                        />
                        <div class="file-info-custom" id="fileInfoUrn">
                            CSV must contain a column named "URN"
                        </div>
                    </div>
                    
                    <div class="form-group-custom">
                        <label class="form-label-custom">Description (Optional)</label>
                        <aui:input 
                            name="description" 
                            type="text" 
                            id="descriptionUrn"
                            placeholder="e.g., Duplicate cleanup for URNs - March 2024"
                            label=""
                        />
                    </div>
                    
                    <button type="submit" class="btn-custom">
                         Clean Duplicates by URN
                    </button>
                </aui:form>
                
                <div class="sample-csv-custom" style="margin-top: 1rem;">
                    <strong>Sample CSV format:</strong><br>
                    URN<br>
                    URN-001-ABC<br>
                    URN-002-DEF<br>
                    URN-001-ABC<br>
                    URN-003-GHI
                </div>
                
                <div class="info-box-custom">
                    <strong>What happens:</strong>
                    <ul class="list-custom">
                        <li>Reads unique URNs from CSV file</li>
                        <li>For each URN, finds all records in database</li>
                        <li>Keeps record with lowest stage (most critical)</li>
                        <li>Generates detailed deletion report</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tab 3: Workflow Cleanup -->
    <div id="workflow" class="tab-content">
        <div class="card-custom">
            <div class="card-header-custom">
                <i></i> Workflow Records Cleanup
            </div>
            <div class="card-body-custom">
                <div class="warning-box-custom" style="background: #fee2e2; border-left-color: #dc2626;">
                    <strong> Caution:</strong> This will permanently delete workflow records. Use with extreme caution.
                </div>
                
                <aui:form action="<%= startBulkWorkflowDeleteURL %>" method="post" enctype="multipart/form-data" name="deleteWorkflowForm">
                    <div class="row-custom">
                        <div class="form-group-custom">
                            <label class="form-label-custom">
                                Class Name ID
                                <span class="required">*</span>
                            </label>
                            <aui:input 
                                name="classNameId" 
                                type="number" 
                                id="classNameId"
                                required="true"
                                label=""
                                placeholder="Enter Class Name ID"
                            >
                                <aui:validator name="required" />
                                <aui:validator name="number" />
                            </aui:input>
                            <div class="file-info-custom">The class name ID for workflow records</div>
                        </div>
                        
                        <div class="form-group-custom">
                            <label class="form-label-custom">
                                Site ID
                                <span class="required">*</span>
                            </label>
                            <aui:input 
                                name="siteId" 
                                type="number" 
                                id="siteId"
                                required="true"
                                label=""
                                placeholder="Enter Site ID"
                            >
                                <aui:validator name="required" />
                                <aui:validator name="number" />
                            </aui:input>
                            <div class="file-info-custom">The site/group ID for workflow records</div>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-custom btn-danger-custom">
                         Delete Workflow Records
                    </button>
                </aui:form>
                
                <div class="warning-box-custom" style="margin-top: 1rem;">
                    <strong> Warning:</strong>
                    <ul class="list-custom">
                        <li>This operation is IRREVERSIBLE</li>
                        <li>Deletes all workflow records matching the criteria</li>
                        <li>Ensure you have correct Class Name ID and Site ID</li>
                        <li>Consider taking backup before proceeding</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tab 4: Update Account Number -->
    <div id="update-account" class="tab-content">
        <div class="card-custom">
            <div class="card-header-custom">
                <i></i> Bulk Update Account Number by URN
            </div>
            <div class="card-body-custom">
                <div class="info-box-custom" style="background: #d1fae5; border-left-color: #10b981;">
                    <strong> Update Strategy:</strong>
                    <ul class="list-custom">
                        <li>Finds record by URN using Elasticsearch</li>
                        <li>Updates the account number field</li>
                        <li>Preserves all other fields</li>
                        <li>Generates detailed update report</li>
                    </ul>
                </div>
                
                <form action="<%= startBulkUpdateAccountNoURL %>" method="post" enctype="multipart/form-data">
                    <div class="form-group-custom">
                        <label class="form-label-custom">
                            CSV File with URN and New Account Number
                            <span class="required">*</span>
                        </label>
                        <div class="upload-area-custom" onclick="document.getElementById('csvUpdateFileInput').click();">
                            <div class="upload-icon"></div>
                            <div class="upload-text">
                                <strong>Click to select</strong> CSV file with URN and Account Number
                            </div>
                        </div>
                        <input type="file" name="csvUpdateFile" id="csvUpdateFileInput" accept=".csv" required style="display: none;"/>
                        <div class="file-info-custom" id="fileInfoUpdate">
                            CSV must contain columns: "URN" and "accountNumber"
                        </div>
                    </div>
                    
                    <div class="row-custom">
                        <div class="form-group-custom">
                            <label class="form-label-custom">URN Column Name</label>
                            <input type="text" name="urnColumnName" class="form-control-custom" value="URN" placeholder="e.g., URN" required>
                            <div class="file-info-custom">Column header containing URN values</div>
                        </div>
                        
                        <div class="form-group-custom">
                            <label class="form-label-custom">Account Number Column Name</label>
                            <input type="text" name="accountNoColumnName" class="form-control-custom" value="accountNumber" placeholder="e.g., accountNumber" required>
                            <div class="file-info-custom">Column header containing new account numbers</div>
                        </div>
                    </div>
                    
                    <div class="form-group-custom">
                        <label class="form-label-custom">CSV Delimiter</label>
                        <select name="delimiter" class="form-control-custom">
                            <option value=",">Comma (,)</option>
                            <option value=";">Semicolon (;)</option>
                            <option value="\t">Tab</option>
                            <option value="|">Pipe (|)</option>
                        </select>
                    </div>
                    
                    <div class="form-group-custom">
                        <label class="form-label-custom">Description (Optional)</label>
                        <input type="text" name="description" class="form-control-custom" placeholder="e.g., Account number correction - March 2024">
                    </div>
                    
                    <button type="submit" class="btn-custom" style="background: linear-gradient(135deg, #10b981 0%, #059669 100%);">
                         Update Account Numbers
                    </button>
                </form>
                
                <div class="sample-csv-custom" style="margin-top: 1rem;">
                    <strong>Sample CSV format:</strong><br>
                    URN,accountNumber<br>
                    URN-001-ABC,123456789012<br>
                    URN-002-DEF,987654321098<br>
                    URN-003-GHI,456789123045
                </div>
                
                <div class="info-box-custom">
                    <strong>What happens:</strong>
                    <ul class="list-custom">
                        <li>Reads URN and new account number from CSV</li>
                        <li>For each URN, finds the record in database using Elasticsearch</li>
                        <li>Updates only the account number field</li>
                        <li>If multiple records found with same URN, updates the one with lowest stage</li>
                        <li>Generates detailed update report with success/failure status</li>
                    </ul>
                </div>
                
                <div class="warning-box-custom">
                    <strong> Important Notes:</strong>
                    <ul class="list-custom">
                        <li>Account numbers will be updated immediately</li>
                        <li>Operation runs in background for large files</li>
                        <li>For duplicate URNs, only the record with lowest stage is updated</li>
                        <li>Track progress in <strong>Control Panel  System  Background Tasks</strong></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tab 5: Export Object Data by URNs (NEW TAB) -->
    <div id="export-data" class="tab-content">
        <div class="card-custom">
            <div class="card-header-custom export-header">
                <i></i> Export Object Data by URNs
            </div>
            <div class="card-body-custom">
                <div class="info-box-custom" style="background: #e0f2fe; border-left-color: #0ea5e9;">
                    <strong> Export Strategy:</strong>
                    <ul class="list-custom">
                        <li>Upload CSV file containing URNs</li>
                        <li>System fetches complete object data for each URN</li>
                        <li>Exports all attributes to a new CSV file</li>
                        <li>Downloadable report with success/failure status</li>
                    </ul>
                </div>
                
                <aui:form action="<%= exportObjectDataByURNsURL %>" method="post" enctype="multipart/form-data" name="exportForm">
                    <div class="form-group-custom">
                        <label class="form-label-custom">
                            CSV File with URNs
                            <span class="required">*</span>
                        </label>
                        <div class="upload-area-custom" onclick="document.getElementById('<portlet:namespace />exportCSVFile').click();">
                            <div class="upload-icon"></div>
                            <div class="upload-text">
                                <strong>Click to select</strong> CSV file with URNs to export
                            </div>
                        </div>
                        <aui:input 
                            name="exportCSVFile" 
                            type="file" 
                            id="exportCSVFile"
                            accept=".csv"
                            required="true"
                            label=""
                            style="display: none;"
                        />
                        <div class="file-info-custom" id="fileInfoExport">
                            CSV must contain a column with URNs
                        </div>
                    </div>
                    
                    <div class="row-custom">
                        <div class="form-group-custom">
                            <label class="form-label-custom">URN Column Name</label>
                            <aui:input 
                                name="urnColumnName" 
                                type="text" 
                                id="urnColumnName"
                                value="URN"
                                placeholder="e.g., URN, urn, referenceId"
                                label=""
                            >
                                <aui:validator name="required" />
                            </aui:input>
                            <div class="file-info-custom">Column header containing URN values</div>
                        </div>
                        
                        <div class="form-group-custom">
                            <label class="form-label-custom">CSV Delimiter</label>
                            <select name="<portlet:namespace />exportDelimiter" id="exportDelimiter" class="form-control-custom">
                                <option value=",">Comma (,)</option>
                                <option value=";">Semicolon (;)</option>
                                <option value="\t">Tab</option>
                                <option value="|">Pipe (|)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-group-custom">
                        <label class="form-label-custom">Select Fields to Export (Optional)</label>
                        <div class="checkbox-group-custom" id="fieldCheckboxes">
                            <label class="checkbox-custom">
                                <input type="checkbox" name="exportFields" value="objectEntryId" checked> Object Entry ID
                            </label>
                            <label class="checkbox-custom">
                                <input type="checkbox" name="exportFields" value="createDate" checked> Create Date
                            </label>
                            <label class="checkbox-custom">
                                <input type="checkbox" name="exportFields" value="modifiedDate" checked> Modified Date
                            </label>
                            <label class="checkbox-custom">
                                <input type="checkbox" name="exportFields" value="status" checked> Status
                            </label>
                            <label class="checkbox-custom">
                                <input type="checkbox" name="exportFields" value="stage" checked> Stage
                            </label>
                            <label class="checkbox-custom">
                                <input type="checkbox" name="exportFields" value="accountNumber" checked> Account Number
                            </label>
                            <label class="checkbox-custom">
                                <input type="checkbox" name="exportAllFields" id="exportAllFields"> Export All Fields
                            </label>
                        </div>
                        <div class="file-info-custom">Leave all unchecked to export all fields</div>
                    </div>
                    
                    <div class="row-custom">
                        <div class="form-group-custom">
                            <label class="form-label-custom">Export File Name (Optional)</label>
                            <aui:input 
                                name="exportFileName" 
                                type="text" 
                                id="exportFileName"
                                placeholder="e.g., object_export_2024_03_21"
                                label=""
                            />
                            <div class="file-info-custom">If empty, auto-generated name will be used</div>
                        </div>
                        
                        <div class="form-group-custom">
                            <label class="form-label-custom">Description (Optional)</label>
                            <aui:input 
                                name="exportDescription" 
                                type="text" 
                                id="exportDescription"
                                placeholder="e.g., Export of active accounts - March 2024"
                                label=""
                            />
                        </div>
                    </div>
                    
                    <button type="submit" class="btn-custom btn-export-custom" onclick="showLoading()">
                         Export Object Data
                    </button>
                </aui:form>
                
                <div class="sample-csv-custom" style="margin-top: 1rem;">
                    <strong>Sample Input CSV format:</strong><br>
                    URN,customColumn<br>
                    URN-001-ABC,optional_data1<br>
                    URN-002-DEF,optional_data2<br>
                    URN-003-GHI,optional_data3
                </div>
                
                <div class="sample-csv-custom" style="background: #e0f2fe;">
                    <strong>Sample Output CSV format (exported data):</strong><br>
                    URN,objectEntryId,createDate,modifiedDate,status,stage,accountNumber,additionalField1,additionalField2,...<br>
                    URN-001-ABC,390811,2024-01-15 10:30:00,2024-02-20 14:45:00,approved,2,123456789012,value1,value2<br>
                    URN-002-DEF,390812,2024-01-16 11:30:00,2024-02-21 15:45:00,pending,1,987654321098,value3,value4<br>
                    ...
                </div>
                
                <div class="warning-box-custom">
                    <strong> Important Notes:</strong>
                    <ul class="list-custom">
                        <li>For duplicate URNs, only the record with lowest stage is exported</li>
                        <li>If a URN is not found, it will be marked as "NOT_FOUND" in the export</li>
                        <li>Large exports run as background task to avoid timeout</li>
                        <li>Track progress in <strong>Control Panel  System  Background Tasks</strong></li>
                        <li>Exported file will be available for download upon completion</li>
                    </ul>
                </div>
                
                <div class="info-box-custom">
                    <strong> Tips:</strong>
                    <ul class="list-custom">
                        <li>Use specific field selection to reduce export file size</li>
                        <li>For large URN lists (over 10,000), the export will be processed in batches</li>
                        <li>You'll receive a notification when the export is ready for download</li>
                        <li>Exported files are stored temporarily and cleaned up after 7 days</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tab 6: Finacle Consent Sync -->
<div id="finacle-consent" class="tab-content">
    <div class="card-custom">
        <div class="card-header-custom" style="background: linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%);">
            <i>📡</i> Finacle Consent Sync
        </div>
        <div class="card-body-custom">
            <div class="info-box-custom" style="background: #ede9fe; border-left-color: #8b5cf6;">
                <strong>📌 Finacle API Integration:</strong>
                <ul class="list-custom">
                    <li>Sends consent data to Finacle core banking system</li>
                    <li>Updates consent, auto-renewal status, and account information</li>
                    <li>Stores API response in object fields (finacleStatus, finacleMessage)</li>
                    <li>Supports automatic retry on failure (max 3 retries)</li>
                </ul>
            </div>
            
            <aui:form action="<%= startFinacleConsentSyncURL %>" method="post" enctype="multipart/form-data" name="finacleForm">
                <div class="form-group-custom">
                    <label class="form-label-custom">Sync Mode</label>
                    <select name="<portlet:namespace />syncMode" id="syncMode" class="form-control-custom" onchange="toggleFinacleFileUpload()">
                        <option value="APPROVED_ONLY">Process All Approved Records (Stage = 3)</option>
                        <option value="CSV">Upload CSV File with Custom Data</option>
                    </select>
                    <div class="file-info-custom">
                        <strong>APPROVED_ONLY:</strong> Automatically fetches all records with stage=3<br>
                        <strong>CSV:</strong> Use custom CSV file with specific URNs
                    </div>
                </div>
                
                <div id="finacleCsvSection" style="display: none;">
                    <div class="form-group-custom">
                        <label class="form-label-custom">
                            CSV File with Consent Data
                            <span class="required">*</span>
                        </label>
                        <div class="upload-area-custom" onclick="document.getElementById('<portlet:namespace />finacleCsvFile').click();">
                            <div class="upload-icon">📄</div>
                            <div class="upload-text">
                                <strong>Click to select</strong> CSV file with consent data
                            </div>
                        </div>
                        <aui:input 
                            name="finacleCsvFile" 
                            type="file" 
                            id="finacleCsvFile"
                            accept=".csv"
                            label=""
                            style="display: none;"
                        />
                        <div class="file-info-custom" id="fileInfoFinacle">
                            CSV must contain: URN, customerId, debitAccount, bimaType (optional)
                        </div>
                    </div>
                    
                    <div class="row-custom">
                        <div class="form-group-custom">
                            <label class="form-label-custom">URN Column Name</label>
                            <input type="text" name="finacleUrnColumnName" class="form-control-custom" value="URN">
                        </div>
                        
                        <div class="form-group-custom">
                            <label class="form-label-custom">Customer ID Column Name</label>
                            <input type="text" name="finacleCustomerIdColumnName" class="form-control-custom" value="customerId">
                        </div>
                    </div>
                    
                    <div class="row-custom">
                        <div class="form-group-custom">
                            <label class="form-label-custom">Debit Account Column Name</label>
                            <input type="text" name="finacleDebitAccountColumnName" class="form-control-custom" value="debitAccount">
                        </div>
                        
                        <div class="form-group-custom">
                            <label class="form-label-custom">Bima Type Column Name</label>
                            <input type="text" name="finacleBimaTypeColumnName" class="form-control-custom" value="bimaType">
                        </div>
                    </div>
                    
                    <div class="form-group-custom">
                        <label class="form-label-custom">CSV Delimiter</label>
                        <select name="finacleDelimiter" class="form-control-custom">
                            <option value=",">Comma (,)</option>
                            <option value=";">Semicolon (;)</option>
                            <option value="\t">Tab</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group-custom">
                    <label class="form-label-custom">Description (Optional)</label>
                    <input type="text" name="finacleDescription" class="form-control-custom" 
                           placeholder="e.g., Bulk consent sync for April 2024">
                </div>
                
                <button type="submit" class="btn-custom" style="background: linear-gradient(135deg, #8b5cf6 0%, #6366f1 100%);">
                    🚀 Start Finacle Consent Sync
                </button>
            </aui:form>
            
            <div class="sample-csv-custom" style="margin-top: 1rem;">
                <strong>Sample CSV format for custom upload:</strong><br>
                URN,customerId,debitAccount,bimaType<br>
                JNS-PMJJBY-24-25-00000149529-473,118495770,444310110004713,JBY<br>
                JNS-PMSBY-24-25-00000149530-123,118495771,444310110004714,SBY
            </div>
            
            <div class="warning-box-custom">
                <strong>⚠️ Important Notes:</strong>
                <ul class="list-custom">
                    <li>For 16+ lac records, processing will take several hours</li>
                    <li>System processes 100 records in parallel with 10 threads</li>
                    <li>Failed requests are automatically retried up to 3 times</li>
                    <li>Check <strong>Control Panel → System → Background Tasks</strong> for progress</li>
                    <li>Results are stored in finacleStatus and finacleMessage fields</li>
                    <li>A detailed CSV report is generated upon completion</li>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>

<script>
// Simple tab switching without external dependencies
function showTab(tabId) {
    // Hide all tab contents
    var tabs = document.getElementsByClassName('tab-content');
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove('active');
    }
    
    // Remove active class from all nav tabs
    var navTabs = document.getElementsByClassName('nav-tab');
    for (var i = 0; i < navTabs.length; i++) {
        navTabs[i].classList.remove('active');
    }
    
    // Show selected tab
    document.getElementById(tabId).classList.add('active');
    
    // Add active class to clicked tab
    event.currentTarget.classList.add('active');
}

// File name display for first form
document.getElementById('<portlet:namespace />csvFile').addEventListener('change', function(e) {
    if (e.target.files && e.target.files[0]) {
        var fileName = e.target.files[0].name;
        var fileSize = (e.target.files[0].size / 1024).toFixed(2);
        document.getElementById('fileInfo').innerHTML = ' Selected: ' + fileName + ' (' + fileSize + ' KB)';
    }
});

// File name display for second form
document.getElementById('<portlet:namespace />csvURNFile').addEventListener('change', function(e) {
    if (e.target.files && e.target.files[0]) {
        var fileName = e.target.files[0].name;
        var fileSize = (e.target.files[0].size / 1024).toFixed(2);
        var infoDiv = document.getElementById('fileInfoUrn');
        if (infoDiv) {
            infoDiv.innerHTML = ' Selected: ' + fileName + ' (' + fileSize + ' KB)';
        }
    }
});

// File name display for update form
document.getElementById('csvUpdateFileInput').addEventListener('change', function(e) {
    if (e.target.files && e.target.files[0]) {
        var fileName = e.target.files[0].name;
        var fileSize = (e.target.files[0].size / 1024).toFixed(2);
        var infoDiv = document.getElementById('fileInfoUpdate');
        if (infoDiv) {
            infoDiv.innerHTML = ' Selected: ' + fileName + ' (' + fileSize + ' KB)';
        }
    }
});

// File name display for export form
document.getElementById('<portlet:namespace />exportCSVFile').addEventListener('change', function(e) {
    if (e.target.files && e.target.files[0]) {
        var fileName = e.target.files[0].name;
        var fileSize = (e.target.files[0].size / 1024).toFixed(2);
        var infoDiv = document.getElementById('fileInfoExport');
        if (infoDiv) {
            infoDiv.innerHTML = ' Selected: ' + fileName + ' (' + fileSize + ' KB)';
        }
    }
});

// Handle "Export All Fields" checkbox
var exportAllCheckbox = document.getElementById('exportAllFields');
if (exportAllCheckbox) {
    exportAllCheckbox.addEventListener('change', function(e) {
        var checkboxes = document.querySelectorAll('#fieldCheckboxes input[type="checkbox"][value]');
        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = e.target.checked;
            checkboxes[i].disabled = e.target.checked;
        }
    });
}

// Show loading overlay when form is submitted
function showLoading() {
    document.getElementById('loadingOverlay').style.display = 'block';
}

// Attach loading to all forms
var forms = document.querySelectorAll('form');
for (var i = 0; i < forms.length; i++) {
    forms[i].addEventListener('submit', function() {
        showLoading();
    });
}

//Toggle CSV file upload section for Finacle
function toggleFinacleFileUpload() {
    var syncMode = document.getElementById('syncMode');
    var csvSection = document.getElementById('finacleCsvSection');
    if (syncMode && csvSection) {
        csvSection.style.display = syncMode.value === 'CSV' ? 'block' : 'none';
    }
}

// File name display for Finacle form
var finacleFileInput = document.getElementById('<portlet:namespace />finacleCsvFile');
if (finacleFileInput) {
    finacleFileInput.addEventListener('change', function(e) {
        if (e.target.files && e.target.files[0]) {
            var fileName = e.target.files[0].name;
            var fileSize = (e.target.files[0].size / 1024).toFixed(2);
            var infoDiv = document.getElementById('fileInfoFinacle');
            if (infoDiv) {
                infoDiv.innerHTML = '✅ Selected: ' + fileName + ' (' + fileSize + ' KB)';
            }
        }
    });
}

// Initialize finacle toggle on page load
document.addEventListener('DOMContentLoaded', function() {
    var syncMode = document.getElementById('syncMode');
    if (syncMode) {
        toggleFinacleFileUpload();
    }
});
</script>